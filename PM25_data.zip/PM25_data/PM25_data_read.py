import torch
import numpy as np
import matplotlib.pyplot as plt
import csv
import pandas as pd
import torch
import numpy as np
from torch.utils.data import Dataset
df = pd.read_csv('Measurement_summary.csv')
df = df[['Station code','Measurement date','PM2.5']]

print(df.shape)
df.head()
unstaked_df = df.copy()
unstaked_df['id'] = df['Station code'].astype(str)
unstaked_df.set_index(['id','Measurement date'], inplace=True)
unstaked_df.drop(['Station code'], axis=1, inplace=True)
unstaked_df = unstaked_df.astype(float).unstack()
unstaked_df.columns = unstaked_df.columns.get_level_values(1)
unstaked_df.head()
data_PM = unstaked_df.values[:,0:17520]
print(data_PM.shape)
for i in range(25):
    for j in range(17519):
        if abs(data_PM[i,j]-data_PM[i,j+1])>=50:
            data_PM[i,j+1] = data_PM[i,j]
zaosheng = np.random.randint(2,4,size=(25,17520))
data_PM = data_PM+zaosheng
print(data_PM.shape)
from scipy.signal import savgol_filter
data_PM = scipy.signal.savgol_filter(data_PM,53,3)  
df = pd.read_csv('Measurement_summary.csv')
df = df[['Station code','Measurement date','Latitude']]

print(df.shape)
df.head()
unstaked_df = df.copy()
unstaked_df['id'] = df['Station code'].astype(str)
unstaked_df.set_index(['id','Measurement date'], inplace=True)
unstaked_df.drop(['Station code'], axis=1, inplace=True)
unstaked_df = unstaked_df.astype(float).unstack()
unstaked_df.columns = unstaked_df.columns.get_level_values(1)
unstaked_df.head()
data_L = unstaked_df.values[:,0:17520]
print(data_L.shape)
df = pd.read_csv('Measurement_summary.csv')
df = df[['Station code','Measurement date','Longitude']]

print(df.shape)
df.head()
unstaked_df = df.copy()
unstaked_df['id'] = df['Station code'].astype(str)
unstaked_df.set_index(['id','Measurement date'], inplace=True)
unstaked_df.drop(['Station code'], axis=1, inplace=True)
unstaked_df = unstaked_df.astype(float).unstack()
unstaked_df.columns = unstaked_df.columns.get_level_values(1)
unstaked_df.head()
data_Lo = unstaked_df.values[:,0:17520]
print(data_Lo.shape)
flow_data = np.stack((data_PM,data_L,data_Lo),axis=2)
flow_data.shape