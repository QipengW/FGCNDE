import torch
import torch.nn.functional as F
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
import scipy.io as scio0
from torch.utils.data import Dataset
class LoadData(Dataset):
    def __init__(self, num_nodes, divide_days, time_interval, history_length, train_mode):


        self.num_nodes = num_nodes
        self.train_mode = train_mode
        self.train_days = divide_days[0]  # 420天
        self.val_days = divide_days[1]  # 30天
        self.test_days = divide_days[2]
        self.history_length = history_length  # 10
        self.time_interval = time_interval  # 60min
        self.one_day_length = int(24 * 60 / self.time_interval)
#         self.graph = A
        #self.graph = A
        #对数据进行预处理，做一个归一化，norm_dim定义了在哪一个维度上进行归一化
        self.flow_data = data

    def __len__(self):
   
        if self.train_mode == "train":
            return self.train_days * self.one_day_length - self.history_length
        elif self.train_mode == "val":
            return self.val_days * self.one_day_length - self.history_length
        elif self.train_mode == "test":
            return self.test_days * self.one_day_length-10
        else:
            raise ValueError("train mode: [{}] is not defined".format(self.train_mode))

    def __getitem__(self, index):  # (x, y), index = [0, L1 - 1]

        if self.train_mode == "train":
            index = index
        elif self.train_mode == "val":
            index += self.train_days * self.one_day_length
        elif self.train_mode == "test":
            index += (self.train_days+self.val_days) * self.one_day_length
        else:
            raise ValueError("train mode: [{}] is not defined".format(self.train_mode))

        data_x, data_y = LoadData.slice_data(self.flow_data, self.history_length, index, self.train_mode)

        data_x = LoadData.to_tensor(data_x).cuda()# [N, H, D]
        data_y = LoadData.to_tensor(data_y).cuda()# [N, 1, D]

        return { "flow_x": data_x, "flow_y": data_y}
   
    """
    定义一些辅助函数
    
    """
        
    def slice_data(data, history_length, index, train_mode):

        if train_mode == "train":
            start_index = index
            end_index = index + history_length
        elif train_mode == "val":
            start_index = index
            end_index = index + history_length
        elif train_mode == "test":
            start_index = index - history_length
            end_index = index
        else:
            raise ValueError("train model {} is not defined".format(train_mode))

        data_x = data[:, start_index: end_index,:] #[N,5,D]
        data_y = data[:, end_index:end_index+10,0]

        return data_x, data_y
     
    def to_tensor(data):
        return torch.tensor(data, dtype=torch.float)
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import os
import time
from torch.utils.data import DataLoader
# 加载数据
train_data = LoadData(num_nodes=25, divide_days=[424,141,141],
                          time_interval=60, history_length=5,
                          train_mode="train")

train_loader = DataLoader(train_data, batch_size=32, shuffle=True, num_workers=0)

val_data = LoadData(num_nodes=25, divide_days=[424,141,141],
                          time_interval=60, history_length=5,
                          train_mode="val")

val_loader = DataLoader(val_data, batch_size=3475, shuffle=False, num_workers=0)

test_data = LoadData( num_nodes=25, divide_days=[424,141,141],
                          time_interval=60, history_length=5,
                          train_mode="test")

test_loader = DataLoader(test_data, batch_size=3470, shuffle=False, num_workers=0)


print(len(train_data))
print(train_data[10515]["flow_x"].size())
print(train_data[10515]["flow_y"].size())
print(len(val_data))
print(val_data[3475]["flow_x"].size())
print(val_data[3475]["flow_y"].size())
print(len(test_data))
print(test_data[3374]["flow_x"].size())
print(test_data[3374]["flow_y"].size())