import torch
import numpy as np
import matplotlib.pyplot as plt
import csv
import pandas as pd
import torch
import numpy as np
from torch.utils.data import Dataset
def get_flow_data(flow_file: str) -> np.array:

    data = np.load(flow_file)

    flow_data = data['data'].transpose([1, 0, 2])[:, :, 0].squeeze()

    return flow_data
flow_data = get_flow_data(flow_file = "PeMS04.npz")
flow_data.shape